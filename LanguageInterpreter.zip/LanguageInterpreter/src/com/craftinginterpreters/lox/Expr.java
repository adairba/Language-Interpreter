package com.craftinginterpreters.lox;

abstract class Expr 
{ 
    abstract String accept(@SuppressWarnings("rawtypes") Visitor visitor);
    abstract Object theAccept(@SuppressWarnings("rawtypes") _Visitor visitor);
    
    


  static class Binary extends Expr 
  {
    Binary(Expr left, Token operator, Expr right) 
    {
      this.left = left;
      this.operator = operator;
      this.right = right;
    }

    final Expr left;
    final Token operator;
    final Expr right;


    @Override
    String accept(@SuppressWarnings("rawtypes") Visitor visitor)
    {
        return visitor.visitBinaryExpr(this);
    }

    @Override
    Object theAccept(@SuppressWarnings("rawtypes") _Visitor visitor)
    {
        return visitor.visitBinaryExpression(this);
    }


  }

  static class Grouping extends Expr
  {
    Grouping(Expr expression)
    {
        this.expression = expression;
    }

    final Expr expression;


    @Override
    String accept(@SuppressWarnings("rawtypes") Visitor visitor)
    {
        return visitor.visitGroupingExpr(this);
    }

    @Override
    Object theAccept(@SuppressWarnings("rawtypes") _Visitor visitor)
    {
        return visitor.visitGroupingExpression(this);
    }
  }

  static class Literal extends Expr
  {
    Literal(Object value)
    {
        this.value = value;
    }

    final Object value;


    @Override
    String accept(@SuppressWarnings("rawtypes") Visitor visitor)
    {
        return visitor.visitLiteralExpr(this);
    }

    @Override
    Object theAccept(@SuppressWarnings("rawtypes") _Visitor visitor)
    {
        return visitor.visitLiteralExpression(this);
    }

  }

  static class Unary extends Expr
  {
    Unary(Token operator, Expr right)
    {
        this.operator = operator;
        this.right = right;
    }

    final Token operator;
    final Expr right;

    @Override
    String accept(@SuppressWarnings("rawtypes") Visitor visitor)
    {
        return visitor.visitUnaryExpr(this);
    }

    @Override
    Object theAccept(@SuppressWarnings("rawtypes") _Visitor visitor)
    {
        return visitor.visitUnaryExpression(this);
    }

  }

    public interface Visitor<T> 
    {
        String visitBinaryExpr(Expr.Binary expr);
        String visitGroupingExpr(Expr.Grouping expr);
        String visitLiteralExpr(Expr.Literal expr);
        String visitUnaryExpr(Expr.Unary expr);


        
    }

    public interface _Visitor<T>
    {
        Object visitBinaryExpression(Expr.Binary expr);
        Object visitGroupingExpression(Expr.Grouping expr);
        Object visitLiteralExpression(Expr.Literal expr);
        Object visitUnaryExpression(Expr.Unary expr);

        

       
    }





  // Other expressions...
}
